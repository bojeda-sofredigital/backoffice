import { render,screen } from "@testing-library/react";
import Button from '../../../../../src/presentation/components/ui/button/button.component';


describe('Button init test',()=>{
    
    const title = 'Aceptar';


    test('The title show into button',()=>{
        
     
        render(<Button  variant="primary" title={title}/>);

       
        const MUIBUTTON = screen.getByRole('button');
     
        expect(MUIBUTTON?.innerHTML).toContain(title);

    })

});