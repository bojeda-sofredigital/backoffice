export interface IPageParameters {
  sortBy: string | null;
  page: number;
  pageSize: number;
  sortDescending: boolean;
}

export interface IPaginatedResponse<T> {
  data: T[];
  count: number;
  parameters: IPageParameters;
}