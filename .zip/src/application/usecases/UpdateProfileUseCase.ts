import type { IProfileUpdateDto } from "../dtos/IProfileUpdateDto";
import type { IProfileRepository } from "../interfaces/IProfileRepository";

export class UpdateProfileUseCase{
    
    constructor(private repo: IProfileRepository){}


    async execute(id: string, data: IProfileUpdateDto){
        return this.repo.updateProfile(id,data);
    }
}