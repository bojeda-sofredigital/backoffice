import type { IProfile } from "../../domain/entities/IProfile";
import type { IPageParameters, IPaginatedResponse } from "../common/IPaginatedResponse";
import type { IProfileUpdateDto } from "../dtos/IProfileUpdateDto";

export interface IProfileRepository {
  getProfiles(params: IPageParameters): Promise<IPaginatedResponse<IProfile>>;
  updateProfile(id: string, payload: IProfileUpdateDto): Promise<IProfile>;
}