export interface IProfileUpdateDto{
    id: number;
}