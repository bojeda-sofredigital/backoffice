import axios from "axios";

//import AuthService from "../../application/features/azure/auth.service";
import { env } from "../../config/env";
import type { IApiHandler, IHttpRequestConfig, IHttpResponse } from "../../../application/interfaces/IApiHandler.interface";


// Construye el Basic a partir de variables de entorno
const user = import.meta.env.VITE_TEMP_BASIC_USER;     // “usr_backoffice”
const pass = import.meta.env.VITE_TEMP_BASIC_PASS;     // tu contraseña

axios.defaults.headers.common["Authorization"] =
  `Basic ${btoa(`${user}:${pass}`)}`;


axios.defaults.baseURL = env.baseURL;

const getConfig = (config: IHttpRequestConfig = {}) => {
  const { baseURL, queryParams, headers, ...rest } = config;
  const storageToken = {
    idToken: '',
    accountId: '',
    username: ''
  }//AuthService.getInstance().getToken();

  return {
    params: queryParams,
    headers: {
      ...headers,
      //Authorization: `Bearer ${storageToken.idToken}`,
      //accountId: storageToken.accountId,
      //username: storageToken.username
    },
    ...(baseURL && { baseURL }),
    ...rest,
  };
};

export const apiHandler: IApiHandler = {
  get: async <T, D = undefined>(
    url: string,
    config?: IHttpRequestConfig,
    data?: D
  ): Promise<IHttpResponse<T, D>> => {
    const axiosResponse = await axios.get<T>(url, {
      data,
      ...getConfig(config),
    });
    return {
      data: axiosResponse.data,
      status: axiosResponse.status,
      headers: axiosResponse.headers,
      request: data || ({} as D),
    };
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  post: async <T = any, D = void>(
    url: string,
    config: IHttpRequestConfig = {},
    data?: D
  ): Promise<IHttpResponse<T, D>> => {
    const axiosResponse = await axios.post<T>(url, data, {
      ...getConfig(config),
    });

    return {
      data: axiosResponse.data,
      status: axiosResponse.status,
      headers: axiosResponse.headers,
      request: data || ({} as D),
    };
  },

  put: async <T, D>(
    url: string,
    config: IHttpRequestConfig = {},
    data?: D
  ): Promise<IHttpResponse<T, D>> => {
    const axiosResponse = await axios.put(url, data, {
      ...getConfig(config),
    });

    return {
      data: axiosResponse.data,
      status: axiosResponse.status,
      headers: axiosResponse.headers,
      request: data || ({} as D),
    };
  },

  delete: async <T, D>(
    url: string,
    config: IHttpRequestConfig = {},
    data?: D
  ): Promise<IHttpResponse<T, D>> => {
    const axiosResponse = await axios.delete(url, {
      data,
      ...getConfig(config),
    });

    return {
      data: axiosResponse.data,
      status: axiosResponse.status,
      headers: axiosResponse.headers,
      request: data || ({} as D),
    };
  },
};