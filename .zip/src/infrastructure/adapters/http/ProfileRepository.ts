import type { IProfileRepository } from "../../../application/interfaces/IProfileRepository";
import type { IPageParameters, IPaginatedResponse } from "../../../application/common/IPaginatedResponse";
import type { IProfile } from "../../../domain/entities/IProfile";
import { apiHandler } from "./apiHandler";
import type { IProfileUpdateDto } from "../../../application/dtos/IProfileUpdateDto";

export class ProfileRepository implements IProfileRepository {


  async updateProfile(id: string, payload: IProfileUpdateDto){
    const res = await apiHandler.put<IProfile>(`/profiles/${id}`,{},payload);

    return res.data;
  }
  async getProfiles(params: IPageParameters): Promise<IPaginatedResponse<IProfile>> {
    
    
    const response = await apiHandler.get<IPaginatedResponse<IProfile>>(
      "/profiles",
      { queryParams: params }
    );
    return response.data;
  }
}