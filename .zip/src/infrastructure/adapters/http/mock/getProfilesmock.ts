export const Mock =  {
    "data": [
        {
            "id": "87fd6043-9735-4c73-b7e5-20a938ff60bb",
            "name": "test6",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-11",
                "GRUPO-AD-10"
            ],
            "users": [
                "ET66666",
                "ET55555"
            ]
        },
        {
            "id": "4cf52483-03c6-44d1-8140-30609ea913d6",
            "name": "test19",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-11",
                "GRUPO-AD-10"
            ],
            "users": [
                "ET55555",
                "ET66666"
            ]
        },
        {
            "id": "13fc5892-9f99-440d-96e3-386b8741a860",
            "name": "test20",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-11",
                "GRUPO-AD-10"
            ],
            "users": [
                "ET66666",
                "ET55555"
            ]
        },
        {
            "id": "f514086e-8f49-43ac-ad04-50b829c3f285",
            "name": "test14",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-10",
                "GRUPO-AD-11"
            ],
            "users": [
                "ET55555",
                "ET66666"
            ]
        },
        {
            "id": "e7fa69bf-75ef-4676-94ad-55aa9bd4fc98",
            "name": "test8",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-10",
                "GRUPO-AD-11"
            ],
            "users": [
                "ET55555",
                "ET66666"
            ]
        },
        {
            "id": "c0555d6b-5d6c-4ad2-b742-623d6c9cf84f",
            "name": "test4",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-11",
                "GRUPO-AD-10"
            ],
            "users": [
                "ET55555",
                "ET66666"
            ]
        },
        {
            "id": "744aba42-6497-46e3-8e05-6df91f4131dc",
            "name": "test16",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-10",
                "GRUPO-AD-11"
            ],
            "users": [
                "ET66666",
                "ET55555"
            ]
        },
        {
            "id": "30e65561-2713-41eb-9c6d-769cbd419c03",
            "name": "test15",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-11",
                "GRUPO-AD-10"
            ],
            "users": [
                "ET55555",
                "ET66666"
            ]
        },
        {
            "id": "448a0e30-4022-4cb1-a8af-77f45d4adf03",
            "name": "test18",
            "description": "prueba",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-10",
                "GRUPO-AD-11"
            ],
            "users": [
                "ET66666",
                "ET55555"
            ]
        },
        {
            "id": "0655fd07-f4c3-4675-a217-79d339a16b2e",
            "name": "test",
            "description": "test descripcion",
            "statusId": 0,
            "statusDescription": "Nuevo",
            "statusColor": "#0451DD",
            "groups": [
                "GRUPO-AD-1"
            ],
            "users": [
                "ET11111"
            ]
        }
    ],
    "count": 22,
    "parameters": {
        "sortBy": null,
        "page": 1,
        "pageSize": 10,
        "sortDescending": true
    }
}