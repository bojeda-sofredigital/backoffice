export const colors = {
  white: "#FFFFFF",
  whiteSmoke: "#F4F4F4",
  black: "#000000",
  black100: "#191919",
  black200: "#000000DE",
  darkBackground: "#282828",
  palette: {
    primary: {
      generalBackground: "#FFFFFF",
      main: "#065FBF", //azul ypf
      light: "#0000ff", 
      dark: "#0b5394",
      contrastText: "#FFFFFF",
    },
    secondary: {
      main: "#49BEFF",
      light: "#E8F7FF",
      dark: "#23afdb",
    },
  },

  action: {
    disableBackground: "#495258",
    hover: "#f6f9fc",
  },

  divider: "#e5eaef",

  blue100: "#EBF3FE",
  blue200: "#539BFF",
  darkBlue: "#1682d4",

  gray50: "#F8F9FA",
  grey100: "#F2F6FA",
  grey200: "#EAEFF4",
  grey300: "#DFE5EF",
  grey400: "#7C8FAC",
  grey500: "#5A6A85",
  grey600: "#2A3547",
  grey700: "#9D9D9D",
  grey800: "#0000006B",
  grey900: "#434343",
  grey1000: "#7B7B7B",
  grey1100: "#0000008A",
  grey1200: "#555555",

  green100: "#49beff",
  green200: "#00B9B4",
  green300: "#A5DC86",
  darkGreen: "#004F43",

  red100: "#FDEDE8",
  paleRed: "#FA896B",
  red300: "#f3704d",

  pink: "#F8D7DA",
  pink100: "#F5C2C7",
  danger: "#B00020",
  darkDanger: "#842029",

  paleYellow: "#FEF5E5",
  yellow100: "#FFAE1F",
  darkYellow: "#ae8e59",
};
