export const sizes = {
  fonts: {
    size: {
      h1: "2.25rem",
      h2: "2.25rem",
      h3: "1.5rem",
      h4: "1.3125rem",
      h5: "1.125rem",
      h6: "1rem",
      body1: "0.875rem",
      body2: "0.75rem",
      subtitle1: "0.875rem",
      subtitile2: "0.875rem",
    },
    weight: {
      body: 400,
      button: 400,
      headers: 600,
      subtitle: 400,
    },
  },
  line: {
    height: {
      h1: "2.75rem",
      h2: "2.25rem",
      h3: "1.75rem",
      h4: "1.6rem",
      h5: "0.5rem",
      h6: "1.2rem",
      body1: "1.334rem",
      body2: "1rem",
    },
  },
  letter: {
    spacing: {
      body2: "0rem",
    },
    transform: {
      capitalize: "capitalize",
    },
  },
  hover: {
    opacity: 0.02,
  },
  borders: {
    radius: {
      root: "7px",
    },
  },
  boxShaddowOverride:"rgb(145 158 171 / 30%) 0px 0px 2px 0px, rgb(145 158 171 / 12%) 0px 12px 24px -4px !important",
};
