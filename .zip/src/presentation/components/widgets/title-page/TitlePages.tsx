import { styled } from '@mui/material/styles';
import React from 'react'
import H4 from '../../ui/H4/H4';
import type { ITitlePagesProp } from './ITitlePagesProp';

const WrapperTitle = styled('div')(({ theme }) => ({
  marginBottom: '0.5%',
  marginLeft: '3%'
}));

export const TitlePages: React.FC<ITitlePagesProp> = ({title}) => {
  return (
      <WrapperTitle>
              <H4>{title}</H4>
        </WrapperTitle>
  )
}
