import React from 'react';
import { styled } from '@mui/material/styles';
import { UserIcon } from '../../ui/icons';

interface BarOrdersProps {
  user: string;
}

const BarBackOfficeNav = styled('nav')(({ theme }) => ({
  position: 'relative',
  top: 'auto',
  left: 0,
  right: 0,
  marginTop: -8,
  borderBottom: '1px solid gray',
  backgroundColor: '#fff',
  zIndex: 1,
  paddingTop: 0,
  paddingBottom: 0,
  paddingRight: 0,
  '@media (max-width:700px)': {
    marginTop: -10,
  },
}));

const NavbarNav = styled('div')(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  width: '100%',
  minHeight: 40,
  marginRight: theme.spacing(1),
}));

const LegendUserAcc = styled('div')({
  display: 'flex',
  padding: 0,
  fontSize: '0.75em',
  width: '75%',
  flexGrow: 1,
});

const TruncContainer = styled('div')({
  display: 'flex',
  width: '100%',
  padding: 0,
  flexGrow: 1,
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
});

const AlignEndDiv = styled('div')({
  display: 'flex',
  alignItems: 'flex-end',
  padding: 0,
  marginLeft: '3%'
});

const UserDiv = styled('div')({
  display: 'flex',
  alignItems: 'center',
  whiteSpace: 'nowrap',
});

const PlrSpan = styled('span')({
  padding: '0px 5px',
});

const BarBackOffice: React.FC<BarOrdersProps> = ({ user }) => (
  <BarBackOfficeNav>
    <NavbarNav>
      <LegendUserAcc>
        <TruncContainer>
          <AlignEndDiv>
            <UserDiv>
              <UserIcon />
              <PlrSpan>{user}</PlrSpan>
            </UserDiv>
          </AlignEndDiv>
        </TruncContainer>
      </LegendUserAcc>
    </NavbarNav>
  </BarBackOfficeNav>
);

export default BarBackOffice;
