export default interface INavBarProps {
    
}