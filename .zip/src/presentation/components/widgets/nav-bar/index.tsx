import * as React from 'react';
import { useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import  LogoYPF  from '../../ui/icons/ypf-logo/ypf-logo';
import { Link } from 'react-router-dom';
import { HOME, ROUTES } from '../../../router/routes';

// Definimos el tipo de menú, con opción a submenús
interface SubItem { label: string, route: string }
interface MenuItemType { label: string, route: string, subItems?: SubItem[]; }

// Ejemplo de páginas, algunas con submenús
const pages: MenuItemType[] =  ROUTES
                               .filter(route=>route.viewNav)
                               .map(route=>{
    let item: MenuItemType = {
      label: route.title,
      route: route.name,
      subItems: route.children.length==0? [] :
                                        route.children
                                        .map(child=>{
                                            let childItem: MenuItemType = {
                                              label: child.title,
                                              route: child.name,
                                              subItems: []                                              
                                            };

                                            return childItem;
                                        })
    };

    return item
});



export default function NavBar() {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const handleOpen = (event: any, idx: number) => {
    if (pages[idx].subItems) {
      setAnchorEl(event.currentTarget);
      setOpenIndex(idx);
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
    setOpenIndex(null);
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Box
            sx={{
              flexGrow: 1,
              display: { xs: 'none', md: 'flex' },
              gap: 2  // más espacio entre menús
            }}
          >
            <LogoYPF link={HOME.name} />
            {pages.map((page, idx) => (
              <React.Fragment key={page.label}>
                <Button
                  onClick={(e) => handleOpen(e, idx)}
                  sx={{ my: 2, color: 'black', display: 'block', mx: 2 }}
                >
                  {
                    (page.subItems??[]).length==0? (<Link 
                                                          to={page.route} 
                                                          style={{textDecoration: 'none', color: 'black'}} 
                                                          className='nav-link'> {page.label}</Link>):
                                                    (page.label)   
                  }
                                   
                </Button>
                { (page.subItems??[]).length>0 && (
                  <Menu
                    anchorEl={anchorEl}
                    open={openIndex === idx}
                    onClose={handleClose}                
                    MenuListProps={{ onMouseLeave: handleClose }}
                  >
                    {(page.subItems??[]).map((sub) => (
                      <MenuItem key={sub.label} onClick={handleClose}>
                        <Link 
                            to={sub.route} 
                            style={{textDecoration: 'none', color: 'black'}} 
                            className='nav-link'> {sub.label}
                        </Link>
                      </MenuItem>
                    ))}
                  </Menu>
                )}
              </React.Fragment>
            ))}
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
