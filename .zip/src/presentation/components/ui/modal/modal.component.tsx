import { useEffect, useState } from 'react';

import type { CustomModalProps } from './modal.interface';
import Button from '@mui/material/Button';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';

export default function CustomModal(props: CustomModalProps) {
  const {
    open: externalOpen,
    onClose: externalOnClose,
    buttonProps,
    title,
    children,
    actions,
    maxWidth
  } = props;

  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    if (externalOpen !== undefined) setIsModalOpen(externalOpen);
  }, [externalOpen]);

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = (event: object, reason: "backdropClick" | "escapeKeyDown") => {
    setIsModalOpen(false);
    if (externalOnClose) externalOnClose(event, reason);
  };

  return (
    <div>
      {buttonProps && (
        <Button variant="outlined" {...buttonProps} onClick={handleOpenModal}>
          {buttonProps.title ?? "MODAL"}
        </Button>
      )}
      <Dialog
        open={isModalOpen}
        onClose={handleCloseModal}
        maxWidth={maxWidth}
        fullWidth         
      >
        <DialogTitle>{title}</DialogTitle>
        <DialogContent dividers={false} style={{ paddingBottom: 0 }}>
          {children}
        </DialogContent>
        <DialogActions>{actions}</DialogActions>
      </Dialog>
    </div>
  );
}