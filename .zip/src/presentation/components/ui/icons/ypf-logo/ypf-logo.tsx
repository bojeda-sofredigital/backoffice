import YPFLogo from './logo-ypf.svg';
import React from 'react';
import { styled } from '@mui/material/styles';
import { Link } from 'react-router-dom';

interface IYPFLogo{
  link: string
}

const Container = styled('div')({
  display: 'flex',
  alignItems: 'center',
  width: 'auto',          // ajusta al contenido
  height: 'auto',         // ajusta al contenido
  gap: '1rem',            // 16px → 1rem
  transform: 'rotate(0deg)',
  opacity: 1,
});

const LogoImage = styled('img')({
  width: '8.5625rem',     // 137px → 8.5625rem
  height: '2rem',         // 32px → 2rem
  objectFit: 'contain',    // mantiene proporciones
});

const Divider = styled('div')({
  width: '2.5rem',        // 40px → 2.5rem
  height: 0,
  borderTop: '0.0625rem solid currentColor', // 1px → 0.0625rem
  transform: 'rotate(-90deg)',
  opacity: 1,
  color: '#AAAAAA'
});

const LogoText = styled('span')({
  fontFamily: 'Open Sans, Arial, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal',
  fontSize: '1rem',       // 16px → 1rem
  lineHeight: 1,          // 100%
  letterSpacing: '0.29em',
  color: '#AAAAAA'
});

const LogoYPF: React.FC<IYPFLogo> = ({link}) => (
  <Container>
    <Link to={link} style={{textDecoration: 'none', display: 'contents'}}>
      <LogoImage src={YPFLogo} alt={'LOGO Back-Office'} />
      <Divider />
      <LogoText>{"Extranet"}</LogoText>
    </Link>
  </Container>
);

export default LogoYPF;
