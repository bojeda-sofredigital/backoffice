import { useState } from 'react';

import {
    Box,
    Menu,
    Button,
    IconButton,
    // MenuItem,
    // ListItemIcon,
    // ListItemText,
    Typography,
    Divider
} from "@mui/material";
// import Avatar from '../../icons/avatar';
import UserAvatar from '../user/user-avatar.component';

const Profile = () => {
   
    const [anchorEl2, setAnchorEl2] = useState(null);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const handleClick = (event: any) => {
        setAnchorEl2(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl2(null);
    };

    //if (!isAuthenticated || inProgress !== InteractionStatus.None) {
      //  return <Loading />;
    //}

    return (
        <Box>
            <IconButton
                size="large"
                aria-label="show 11 new notifications"
                color="inherit"
                aria-controls="msgs-menu"
                aria-haspopup="true"
                sx={{
                    ...(typeof anchorEl2 === "object" && {
                        color: "primary.main",
                    }),
                }}
                onClick={handleClick}
            >
                <UserAvatar name="Brian" />
            </IconButton>
            {/* ------------------------------------------- */}
            {/* Message Dropdown */}
            {/* ------------------------------------------- */}
            <Menu
                id="msgs-menu"
                anchorEl={anchorEl2}
                keepMounted
                open={Boolean(anchorEl2)}
                onClose={handleClose}
                anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
                transformOrigin={{ horizontal: "right", vertical: "top" }}
                sx={{
                    "& .MuiMenu-paper": {
                        width: "360px",
                    },
                }}
            >
                <Box padding={3}>
                    <Typography variant="subtitle2" fontWeight={600} color={"rgb(42, 53, 71)"}>CUENTA</Typography>
                    <Typography variant="subtitle2">BOJEDA</Typography>
                </Box>
                <Divider />
                {/* <MenuItem>
                        <ListItemIcon>
                            <IconUser width={20} />
                        </ListItemIcon>
                        <ListItemText>My Profile</ListItemText>
                    </MenuItem> */}
                <Box mt={1} py={1} px={2}>
                    <Button onClick={() => { alert("Exit"); }} variant="outlined" color="primary" fullWidth>
                        Logout
                    </Button>
                </Box>
            </Menu>
        </Box>
    );
};

export default Profile;
