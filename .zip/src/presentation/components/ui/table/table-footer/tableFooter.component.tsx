import TableFooter  from '@mui/material/TableFooter';
import TablePaginationActions from "@mui/material/TablePaginationActions";
import React from "react";
import type { ITableFooter } from "./tableFooter.interface";
import TableRow from "@mui/material/TableRow";
import TablePagination from "@mui/material/TablePagination";

export const CustomTableFooter: React.FC<ITableFooter> = ({
  // row,
  columns,
  page = 0,
  pageSize = 10,
  totalCount,
  handleChangePage,
  handleChangeRowsPerPage,
  labelRowsPerPage = "Filas por página",
}) => {
  // const totalRows = row.length;

  return (
    <TableFooter>
      <TableRow>
        <TablePagination
          rowsPerPageOptions={[2, 5, 10]}
          colSpan={columns? columns.length : undefined}
          count={totalCount}
          rowsPerPage={pageSize}
          page={page}
          labelRowsPerPage={labelRowsPerPage}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          slotProps={{
            select: {
              inputProps: {
                "aria-label": "rows per page",
              },
              native: true,
            },
          }}
          ActionsComponent={TablePaginationActions}
        />
      </TableRow>
    </TableFooter>
  );
};
