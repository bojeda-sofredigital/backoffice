import { TableHead, TableRow, Typography } from "@mui/material"
import type { ITableHeader } from "./tableHeader.interface"
import { StyledTableCell } from "../table.styles"


function CustomTableHeader({ columns }: ITableHeader) {
  return (
    <TableHead>
      <TableRow>
        {columns.map((column) => (
          <StyledTableCell key={column.id} align={column.align || "left"}>
            <Typography variant="h6">{column.label}</Typography>
          </StyledTableCell>
        ))}
      </TableRow>
    </TableHead>
  )
}

export default CustomTableHeader