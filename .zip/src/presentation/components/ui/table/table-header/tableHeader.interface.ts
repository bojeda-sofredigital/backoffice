import type { IColumn } from "../table.interface";

export interface ITableHeader {
  columns: IColumn[];
}
