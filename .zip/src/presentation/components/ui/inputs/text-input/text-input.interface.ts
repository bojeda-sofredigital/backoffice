import { type TextFieldProps } from "@mui/material";
import type { FieldValues } from "react-hook-form";
import type { CustomControllerProps } from "../controller.interface";

export type ITextInput<T extends FieldValues> =
  Omit<TextFieldProps, 'size'> &
  CustomControllerProps<T> &
  {
    size?: 'small' | 'medium' | 'large';
  };