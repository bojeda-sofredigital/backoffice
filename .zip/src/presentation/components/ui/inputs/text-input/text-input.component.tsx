import { InputLabel } from "@mui/material";
import TextField from "@mui/material/TextField";
import { Controller, type FieldValues } from "react-hook-form";
import Required from "../../required/required.component";
import { styles } from "../styles";
import type { ITextInput } from "./text-input.interface";

function CustomTextInput<T extends FieldValues>(props: ITextInput<T>) {
  const {
    size = "small",
    defaultValue = '',
    label,
    required,
    value,
    type = "text",
    onChange,
    control,
    name,
    rules,
    ...rest
  } = props;

  return (
    <div>
      <InputLabel sx={styles.label}>
        {label}
        {required && <Required value="*" />}
      </InputLabel>
      {control && name ? (
        <Controller
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        defaultValue={defaultValue as any}
        control={control}
        name={name}
        rules={rules}
        render={({ field: { onChange, onBlur, value }, fieldState: { error } }) => (
          <TextField
            {...rest}
            sx={styles[size]}
            error={error !== undefined}
            helperText={error?.message}
            onBlur={onBlur}
            onChange={(e) => {
              const newValue = type === "number" ? parseInt(e.target.value) : e.target.value;
              onChange(newValue);
            }}
            value={value}
            type={type}
          />
          )}
        />
      ) : (
        <TextField
          {...rest}
          sx={styles[size]}
          id="outlined-basic"
          variant="outlined"
          value={value}
          onChange={onChange}
        />
      )}
    </div>
  );
}

export default CustomTextInput;
