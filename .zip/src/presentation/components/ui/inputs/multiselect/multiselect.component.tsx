import React from "react";
import { Controller, type FieldValues } from "react-hook-form";
import { Autocomplete, TextField, FormControl, InputLabel } from "@mui/material";
import type { IMultiselect, SelectOption } from "./multiselect.interface";
import { styles } from "../styles";
import Required from "../../required/required.component";

function CustomMultiselect<T extends FieldValues>(props: IMultiselect<T>) {
  const {
    size='large',
    options = [],
    placeholder,
    label,
    required,
    value,
    onChange,
    control,
    name,
    rules,
    ...rest
  } = props;

  const handleChange = (
    event: React.SyntheticEvent<Element, Event>,
    newValue: SelectOption[],
  ) => {
    const transformedValue = newValue.map(option => ({ id: option.id, name: option.name }));
    if (onChange) {
      onChange(event, transformedValue);
    }
  };

  return (
    <div>
      {label && (
        <InputLabel sx={styles.label}>
          {label}
          {required && <Required value="*" />}
        </InputLabel>
      )}
      {control && name ? (
        <FormControl sx={styles[size]}>
          <Controller
            control={control}
            name={name}
            rules={rules}
            render={({
              field: { value, onChange: fieldOnChange, ...field },
              fieldState: { error },
            }) => (
              <Autocomplete
                multiple
                options={options}
                getOptionLabel={(option) => (option?.name ? option.name : "")}
                getOptionKey={(option: any) => option?.id.toString() ? option.id.toString() : ""}
                isOptionEqualToValue={(option, value) => {
                  return option.name === value.name;
                }}
                value={value || []}
                onChange={(event, newValue) => {
                  handleChange(event, newValue);
                  fieldOnChange(newValue);
                }}
                renderInput={(params) => {
                  return (
                    <TextField
                      {...params}
                      {...field}
                      error={!!error}
                      placeholder={placeholder}
                      sx={{
                        ...styles[size],
                        ...(!value?.length && { color: "#00000060" }),
                      }}
                    />
                  );
                }}
                {...rest}
              />
            )}
          />
        </FormControl>
      ) : (
        <FormControl sx={styles[size]}>
          <Autocomplete
            multiple
            options={options}
            getOptionLabel={(option) => (option?.name ? option.name : "")}
            isOptionEqualToValue={(option, value) => option.id === value.id}
            value={value || []}
            onChange={(event, newValue) => handleChange(event, newValue)}
            renderInput={(params) => {
              return (
                <TextField
                  {...params}
                  placeholder={placeholder}
                  sx={styles[size]}
                />
              );
            }}
            {...rest}
          />
        </FormControl>
      )}
    </div>
  );
}

export default CustomMultiselect;