import { Controller, type FieldValues } from 'react-hook-form';
import { FormControl, FormControlLabel, RadioGroup, Radio, FormLabel } from '@mui/material';
import type { IRadioButton } from './radio-button.interface';
import { styles } from '../styles';
import Required from '../../required/required.component';

interface CustomRadioButtonProps<T extends FieldValues> extends IRadioButton<T> {
  radioGroupProps?: object;
}

function CustomRadioButton<T extends FieldValues>(props: CustomRadioButtonProps<T>) {
  const { size = 'small', options, label, required, value, onChange, control, name, rules, radioGroupProps, ...rest } = props;

  console.log('OPTIONS: ', options);

  return (
    <div>
      <FormLabel sx={styles.label}>
        {label}
        {required && <Required value='*' />}
      </FormLabel>
      {control && name ? (
        <FormControl component="fieldset" sx={styles[size]}>
          <Controller
            control={control}
            name={name}
            rules={rules}
            render={({ field: { value, onChange, ...field } }) => (
              <RadioGroup
                value={value}
                onChange={(e) => onChange(Number(e.target.value))} // Convert value to number
                {...field}
                {...radioGroupProps}
                {...rest}
              >
                {options?.map(option => (
                  <FormControlLabel
                    key={(option.value ?? '').toString()} // Provide a default value if option.value is null or undefined
                    value={option.value}
                    control={<Radio />}
                    label={option.label}
                  />
                ))}
              </RadioGroup>
            )}
          />
        </FormControl>
      ) : (
        <FormControl component="fieldset" sx={styles[size]}>
          <RadioGroup
            value={value}
            onChange={onChange}
            {...radioGroupProps}
            {...rest}
          >
            {options.map(option => (
              <FormControlLabel
                key={(option.value ?? '').toString()} 
                value={option.value}
                control={<Radio />}
                label={option.label}
              />
            ))}
          </RadioGroup>
        </FormControl>
      )}
    </div>
  );
}

export default CustomRadioButton;