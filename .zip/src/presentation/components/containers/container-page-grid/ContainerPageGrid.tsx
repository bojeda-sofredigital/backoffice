import React, { type JSX } from 'react'
import Container from '../../ui/container'
import BarBackOffice from '../../widgets/bar-backoffice/BarBackOffice';
import H4 from '../../ui/H4/H4';
import { styled } from '@mui/material/styles';
import { TitlePages } from '../../widgets/title-page/TitlePages';
import Loading from '../../ui/loading';
import { CustomStack } from '../../ui/stack/Stack';
import { colors } from '../../../common/colors';
import { Button } from '../../ui/button';
import CustomDivider from '../../ui/divider';

export interface IContainerPageProp{
    children: any,
    description: string,
    title: string,
    count: number,
    loading?: boolean,
    filter?: JSX.Element
}


const WrapperContainerPage = styled('div')(({ theme }) => ({
  marginTop: '5%',
  paddingLeft: '3%',
  paddingRight: '3%',
}));

const StyledCountElement = styled('div')(({ theme }) => ({
  color: colors.black,
  alignContent: 'end'
}));

const styleContentElementFind = {
    justifyContent: "space-between"
}

const StyleContentLoading = styled('div')(({ theme }) => ({
    position: 'fixed',
    inset: 0,
    width: '100vw',    
    height: '100vw',
    userSelect: 'none',
    zIndex: 9999,
    backgroundColor: 'rgb(0, 0, 0, 0.1)',
    paddingTop: '30%'    
}));
export const ContainerPageGrid: React.FC<IContainerPageProp> = ({children,description,title,count,loading= false,filter}) => {
  return (
   <Container description={description}>
          <TitlePages title={title} />
          <BarBackOffice user={'Brian Ojeda'} />
          <WrapperContainerPage>
             {            
              <>
              {loading && (<StyleContentLoading><center> <Loading /> </center></StyleContentLoading>)}              
              <CustomStack direction='row' sx={styleContentElementFind}>
                    <StyledCountElement>
                        { `Encontramos ${count} elementos`}
                    </StyledCountElement>
                    {filter??<></>}                    
                </CustomStack>
              <CustomDivider />
            
              {children}</>
             }
         </WrapperContainerPage>                       
   </Container>
  )
}
