import React from 'react'
import Container from '../../ui/container'
import BarBackOffice from '../../widgets/bar-backoffice/BarBackOffice';
import H4 from '../../ui/H4/H4';
import { styled } from '@mui/material/styles';
import { TitlePages } from '../../widgets/title-page/TitlePages';

export interface IContainerPageProp{
    children: any,
    description: string,
    title: string
}


const WrapperContainerPage = styled('div')(({ theme }) => ({
  paddingLeft: '3%',
  paddingRight: '3%'
}));
export const ContainerPage: React.FC<IContainerPageProp> = ({children,description,title}) => {
  return (
   <Container description={description}>
          <TitlePages title={title} />
          <BarBackOffice user={'Brian Ojeda'} />
          <WrapperContainerPage>
            {children}
         </WrapperContainerPage>                       
   </Container>
  )
}
