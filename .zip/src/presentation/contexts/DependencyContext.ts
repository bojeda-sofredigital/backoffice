import React from 'react';

import { GetProfilesUseCase } from '../../application/usecases/GetProfilesUseCase';
import { ProfileRepository } from '../../infrastructure/adapters/http/ProfileRepository';
import { UpdateProfileUseCase } from '../../application/usecases/UpdateProfileUseCase';

const profileRepo = new ProfileRepository();


export interface IDependencies{
  getProfiles: GetProfilesUseCase,
  updateProfile: UpdateProfileUseCase
}


export const defaultDependencies: IDependencies = {
  getProfiles: new GetProfilesUseCase(profileRepo),
  updateProfile: new UpdateProfileUseCase(profileRepo)
};

export const DependencyContext = React.createContext<IDependencies>(defaultDependencies);
