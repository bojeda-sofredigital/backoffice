import React from 'react'
import type LayoutProps from '../interface/layout.interface'

import NavBar from '../../components/widgets/nav-bar';
import { styled } from '@mui/material/styles';

const MainWrapper = styled("div")(() => ({
  display: "flex",
  height: "100vh",
  overflowY: "scroll",
  width: "100%",
  position: "relative",
})).withComponent('div');

const PageWrapper = styled("div")(() => ({
  flexGrow: 1,
  paddingBottom: "50px",
  flexDirection: "column",
  zIndex: 1,
}));
export const MainBackOffice: React.FC<LayoutProps> = ({ children }) => {
  return (
    <MainWrapper>
        <PageWrapper>
            <NavBar />
            {children}
        </PageWrapper>
        
    </MainWrapper>
  )
}
