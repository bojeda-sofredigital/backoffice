import type { IColumn } from "../../../../../components/ui/table/table.interface";

export const Headers: IColumn[] =[{
    align: 'center',
    id: 'name',
    label: 'Nombre'
},{
    align: 'center',
    id: 'state',
    label: 'Estado'
},{
    align: 'center',
    id: 'description',
    label: 'Descripcion'
},{
    align: 'center',
    id: 'groupsUsers',
    label: 'Grupos | Usuarios'
},{
    align: 'center',
    id: 'actions',
    label: 'Acciones'
}];