import React, { useContext } from 'react'
import CustomTable from '../../../../components/ui/table/table.component'
import { ContainerPageGrid } from '../../../../components/containers/container-page-grid/ContainerPageGrid';
import { Button } from '../../../../components/ui/button';
import { CustomStack } from '../../../../components/ui/stack/Stack';
import { DependencyContext } from '../../../../contexts/DependencyContext';

import { Headers } from './constants/configTable';
import type { IAction } from '../../../../components/ui/table/table-actions/actions.interface';
import type { IRow } from '../../../../components/ui/table/table.interface';
import { toProfileRow, type IProfileRow } from '../../mappers/profileMapper';
import { useGetProfiles } from '../../hooks/useGetProfiles';
import { Navigate, useNavigate } from 'react-router-dom';
import { NEW_PROFILE } from '../../../../router/routes';


export const ProfilesPage = () => {

  const navigate = useNavigate();
  const { getProfiles } = useContext(DependencyContext);
  const { result, loading, params, setParams } = useGetProfiles(getProfiles, {
    page: 1, pageSize: 10, sortBy: null, sortDescending: true
  });

  
  const handleOnClickEditGroup = (row: IRow)=>{
    console.log(row);
    alert('Estoy haciendo click')
  }
  
  const profileRows: IProfileRow[] = result? result.data.map((row)=>{
    return toProfileRow(row,handleOnClickEditGroup);
  }) : [];

  const filterButtons = <>
    <CustomStack direction="row" spacing={2}>
                        <Button variant={'primary'} title='Crear nuevo perfil' onClick={()=>{navigate(NEW_PROFILE.name)}}/>
                        <Button variant={'secondary'} title='Filtrar' />
    </CustomStack>
  </>

  const actions: IAction[] = [{
    icon: <Button variant={'secondary'} title='Editar' />,
    onClick: ((rowData: IRow)=>{
        console.log('Valor de row: ',rowData);
    })
  }]
  return (    
    <ContainerPageGrid 
                description={'ProfilesPage'} 
                title={"Gestion de perfil de usuario - Perfiles"}  
                loading={loading} 
                count={!result? 0 : result.count}
                filter={filterButtons}>               
            
            <CustomTable 
                  columns={Headers} 
                  data={profileRows} 
                  page={params.page - 1} 
                  totalCount={result?.count??0} 
                  pageSize={params.pageSize} 
                  handleChangePage={(_, newPage) => {
                    
                    setParams({ ...params, page: newPage + 1 });
                  }}
                  handleChangeRowsPerPage={e => {
                      const newSize = parseInt(e.target.value, 10);
                      // al cambiar tamaño, volvemos a la primera página
                      setParams({ ...params, pageSize: newSize, page: 1 });
                  }}
                 actions={actions}
                 />
                    
    </ContainerPageGrid>
  )
}
