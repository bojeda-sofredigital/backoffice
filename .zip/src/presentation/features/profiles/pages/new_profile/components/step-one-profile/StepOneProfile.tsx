import React from 'react'
import { ProfileForm } from '../profile-form-values/ProfileFormValues'
import H5 from '../../../../../../components/ui/H5/H5'
import { CustomBox } from '../../../../../../components/ui/box/CustomBox'
import { CustomStack } from '../../../../../../components/ui/stack/Stack'
import { Controller, useForm } from 'react-hook-form'
import CustomTextInput from '../../../../../../components/ui/inputs/text-input/text-input.component'
import CustomTextAreaInput from '../../../../../../components/ui/inputs/text-area-input/text-area-input.component'
import CustomSelect from '../../../../../../components/ui/inputs/select/select.component'
import type { SelectOption } from '../../../../../../components/ui/inputs/select/select.interface'
import CustomDivider from '../../../../../../components/ui/divider'
import type { ProfileFormValues } from '../../NewProfilePage'


const defaultValues: ProfileFormValues = {
  name: '',
  description: '',
  status: 'Nuevo',
  groups: [],
  users: []
}

const options: SelectOption[] = [{
  value: '1',
  label: 'Nuevo'
},{
  value: '2',
  label: 'Activo'
},{
  value: '3',
  label: 'Inactivo'
}]
export const StepOneProfile = ({ onSubmit }: { onSubmit: (v: ProfileFormValues) => void }) => {

  const {
      handleSubmit,
      control,
      formState: { errors, isSubmitting }
    } = useForm<ProfileFormValues>({ defaultValues, mode: 'onBlur' })
  

  return (
   <>
    
    <H5>Nombre y descripción</H5>
    
    <span>Escriba un nombre, descripción del grupo y el estado de la cuenta. </span>
    
    <CustomDivider />

    <CustomBox component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
          <CustomStack spacing={2}>
                {/* Nombre */}            
                <CustomTextInput 
                    control={control} 
                    name='name' 
                    label='Nombre' 
                    rules={{ required: 'El nombre es obligatorio' }}                
                />
        
                {/* Descripción */}
                <CustomTextAreaInput  
                  name="description"
                  control={control}
                  label="Descripción"
                />            
                {/* Estado */}
              <CustomSelect  options={options} control={control} name='status' label='Estado'/>
          </CustomStack>
        </CustomBox>
     
   </>

  )
}
