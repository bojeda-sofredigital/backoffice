import React from 'react'
import { useForm, Controller } from 'react-hook-form'
import { CustomBox } from '../../../../../../components/ui/box/CustomBox'
import { CustomStack } from '../../../../../../components/ui/stack/Stack'
import TextField from '@mui/material/TextField'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import Autocomplete from '@mui/material/Autocomplete'
import { Button } from '../../../../../../components/ui/button'


interface ProfileFormValues {
  name: string
  description: string
  status: 'Nuevo' | 'Activo' | 'Inactivo'
  groups: string[]
  users: string[]
}

const defaultValues: ProfileFormValues = {
  name: '',
  description: '',
  status: 'Nuevo',
  groups: [],
  users: []
}

export function ProfileForm({ onSubmit }: { onSubmit: (v: ProfileFormValues) => void }) {
  const {
    handleSubmit,
    control,
    formState: { errors, isSubmitting }
  } = useForm<ProfileFormValues>({ defaultValues, mode: 'onBlur' })

  let allUsers: any = [];
  let allGroups: any = [];

  return (
    <CustomBox component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
      <CustomStack spacing={2}>
        {/* Nombre */}
        <Controller
          name="name"
          control={control}
          rules={{ required: 'El nombre es obligatorio' }}
          render={({ field }) => (
            <TextField
              {...field}
              label="Nombre"
              error={!!errors.name}
              helperText={errors.name?.message}
              fullWidth
            />
          )}
        />

        {/* Descripción */}
        <Controller
          name="description"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              label="Descripción"
              multiline
              rows={3}
              fullWidth
            />
          )}
        />

        {/* Estado */}
        <FormControl fullWidth error={!!errors.status}>
          <InputLabel>Status</InputLabel>
          <Controller
            name="status"
            control={control}
            render={({ field }) => (
              <Select {...field} label="Status">
                <MenuItem value="Nuevo">Nuevo</MenuItem>
                <MenuItem value="Activo">Activo</MenuItem>
                <MenuItem value="Inactivo">Inactivo</MenuItem>
              </Select>
            )}
          />
        </FormControl>

        {/* Grupos (multi‐select) */}
        <FormControl fullWidth>
          <InputLabel>Grupos</InputLabel>
          <Controller
            name="groups"
            control={control}
            render={({ field }) => (
              <Select
                {...field}
                multiple
                label="Grupos"
                renderValue={selected => (selected as string[]).join(', ')}
              >
                {/* Suponiendo que tienes un array de opciones `allGroups` */}
                {allGroups.map((g: any) => (
                  <MenuItem key={g} value={g}>
                    {g}
                  </MenuItem>
                ))}
              </Select>
            )}
          />
        </FormControl>

        {/* Usuarios (autocomplete multi) */}
        <Controller
          name="users"
          control={control}
          render={({ field }) => (
            <Autocomplete
              {...field}
              multiple
              options={allUsers}
              getOptionLabel={u => u}
              onChange={(_, v) => field.onChange(v)}
              renderInput={params => (
                <TextField {...params} label="Usuarios" fullWidth />
              )}
            />
          )}
        />

        {/* Botones de acción */}
        <CustomBox display="flex" justifyContent="flex-end" gap={1}>
          <Button onClick={() => /* cerrar modal */ null} variant='primary' title='Cancelar' />
          <Button type="submit" variant="primary" disabled={isSubmitting} title='Guardar' />
        </CustomBox>
      </CustomStack>
    </CustomBox>
  )
}