import StepNavigationBackOffice, { type StepType } from "../../../../components/ui/step/step-navigation-backoffice";
import StepperWrapperBackOfficeDefault from '../../../../components/ui/step/stepper-wrapper-backoffice-default';
import { useState } from "react";
import { ContainerPage } from "../../../../components/containers/container-page/ContainerPage";
import { CheckListIcon, UserIcon } from "../../../../components/ui/icons";
import { CustomBox } from "../../../../components/ui/box/CustomBox";
import { CustomStack } from "../../../../components/ui/stack/Stack";
import { Controller } from "react-hook-form";
import TextField from "@mui/material/TextField";
import { StepOneProfile } from "./components/step-one-profile/StepOneProfile";

  const KEY_STEP_NAME: string = 'Nombre';
  const KEY_STEP_ASSIGNMENT: string = 'Asignacion';

 let ConfigStepProfile: StepType[] = [{
  show: true,
  active: true,
  icon: <UserIcon />,
  title: KEY_STEP_NAME,
},{
  show: true,
  active: false,
  icon: <CheckListIcon />,
  title: KEY_STEP_ASSIGNMENT
}]

export interface ProfileFormValues {
  name: string
  description: string
  status: 'Nuevo' | 'Activo' | 'Inactivo'
  groups: string[]
  users: string[]
}


export const NewProfilePage = () => {
  const [stepActive, setStepActive ] = useState(ConfigStepProfile);


const ChangeStep = (key: string) => {
  setStepActive(
    ConfigStepProfile.map(x =>
      x.title === key
        ? { ...x, active: true }
        : { ...x, active: false }
    )
  );
};

const submit = (value: any)=>{};
  return (
    <ContainerPage description={'NewProfilePage'} title={"Gestion de perfil de usuario - Alta"}>
      <StepperWrapperBackOfficeDefault >
          <StepNavigationBackOffice steps={stepActive} ></StepNavigationBackOffice>
      </StepperWrapperBackOfficeDefault>
        
      <CustomBox sx={{padding: 10}}>
        <StepOneProfile onSubmit={submit} />
        <button onClick={()=>ChangeStep(KEY_STEP_ASSIGNMENT)}>Prueba cambio</button>
      </CustomBox>
    </ContainerPage>
 
  );
};

