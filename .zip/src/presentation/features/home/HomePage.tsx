import { ContainerPage } from '../../components/containers/container-page/ContainerPage';
import DashboardCard from '../../components/ui/card/dashboard';
import MantenimientoSVG from './../../../../public/assets/img/mantenimiento.svg';

export const HomePage = () => {
  return (
    <ContainerPage description={'Home'} title={'Inicio'}>
            <DashboardCard title='En construccion'>
                <img src={MantenimientoSVG} alt="" />
            </DashboardCard>
    </ContainerPage>
 
  );
};
 