import React from "react";
import { ProtectedRoute } from "./ProtectedRoute";
import { MainBackOffice } from "../layout/backoffice/MainBackOffice";

const Root: React.FC = () => {

    return (
        <MainBackOffice>
            <ProtectedRoute />
        </MainBackOffice>
    );
}

export default Root;