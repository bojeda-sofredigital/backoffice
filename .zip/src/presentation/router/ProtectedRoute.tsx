import { Routes, Route } from 'react-router-dom';

import { HOME, NEW_PROFILE, FATHER_PROFILE, NEW_DYNAMIC_PAGE } from './routes';
import { NewProfilePage } from '../features/profiles/pages/new_profile/NewProfilePage';
import { ProfilesPage } from '../features/profiles/pages/profiles/ProfilesPage';
import { HomePage } from '../features/home/HomePage';
import { NewDynamicPagePage } from '../features/dynamic-page/pages/new_page/NewDynamicPagePage';

export const ProtectedRoute = () => (
  <Routes>   
    <Route
      path={HOME.name}
      element={        
          <HomePage />       
      }
    />
     <Route
      path={NEW_PROFILE.name}
      element={        
          <NewProfilePage />       
      }
    />
     <Route
      path={FATHER_PROFILE.name}
      element={        
          <ProfilesPage />       
      }
    />
     <Route
      path={NEW_DYNAMIC_PAGE.name}
      element={        
          <NewDynamicPagePage />       
      }
    />
  </Routes>
);