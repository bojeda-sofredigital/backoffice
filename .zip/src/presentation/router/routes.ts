export interface IRoute {
    title: string;
    name: string;
    viewNav: boolean;
    children: IRoute[];

}


export const HOME: IRoute = {
    title: 'Inicio',
    name: '/',
    children: [],
    viewNav: false
}



export const NEW_PROFILE: IRoute = {
    title: 'Nuevo',
    name: '/new_profile',
    children: [],
    viewNav: true
}
export const NOTIFICATION: IRoute = {
    title: 'Notificaciones',
    name: 'notifications',
    children: [],
    viewNav: true
}
export const FUNTIONALITIES: IRoute = {
    title: 'Funcionalidades',
    name: 'funtionalities',
    children: [],
    viewNav: true
}
export const UPLOAD_PACK: IRoute = {
    title: 'Subir pack',
    name: 'upload_pack',
    children: [],
    viewNav: true
}

export const FATHER_PROFILE: IRoute = {
    title: 'Gestion de perfiles',
    name: '/profiles',
    children: [],
    viewNav: true
}
export const NEW_DYNAMIC_PAGE: IRoute = {
    title: 'Nueva pagina dinamica',
    name: '/dynamic_page',
    children: [],
    viewNav: true
}
export const ROUTES: IRoute[] =[
    HOME, FATHER_PROFILE, NOTIFICATION, FUNTIONALITIES, UPLOAD_PACK, NEW_DYNAMIC_PAGE
];
