import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path';
import {fileURLToPath} from 'url';
// https://vite.dev/config/

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig({
  plugins: [react()],
 // cacheDir: path.resolve(__dirname,'..','..','..','.vitecache'), 
  build: {
    outDir: 'build'
  }, 
  server: {
    watch: {
      // ignora la carpeta de cache para evitar file‑locks
      ignored: ['**/.vitecache/**']
    }
  },
  optimizeDeps: {
    // Forzar la pre‑bundling de estas librerías ligeras que usas a menudo
    include: [
      'react',
      'react-dom',
      '@mui/material',
      '@emotion/react',
      '@emotion/styled'
    ],
    // Excluir las librerías pesadas para que no entren en el bundle inicial
    exclude: [
      '@mui/icons-material',     // iconos MUI son muy grandes     
      '@mui/lab',                // componentes experimentales
      'date-fns',                // si solo lo usas en un hook específico
      'lodash'                   // full build de lodash
    ]
  }
})
