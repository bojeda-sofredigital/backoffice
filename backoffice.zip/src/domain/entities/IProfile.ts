export interface IProfile {
  id: string;
  name: string;
  description: string;
  statusId: number;
  statusDescription: string;
  statusColor: string;
  groups: string[];
}