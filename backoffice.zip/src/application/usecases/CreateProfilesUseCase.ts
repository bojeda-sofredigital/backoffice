import type { IProfileCreateDto } from "../dtos/IProfileCreateDto";
import type { IProfileRepository } from "../interfaces/IProfileRepository";

export class CreateProfileUseCase {
    
  constructor(private repo: IProfileRepository) {}

  execute(dto: IProfileCreateDto): Promise<string> {
    return this.repo.createProfile(dto)
  }
}