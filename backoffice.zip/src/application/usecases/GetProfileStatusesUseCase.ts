import type { IStatuses } from "../../domain/entities/IStatuses";
import type { IPageParameters, IPaginatedResponse } from "../common/IPaginatedResponse";
import type { IProfileRepository } from "../interfaces/IProfileRepository";

export class GetProfileStatusesUseCase {

     constructor(private repo: IProfileRepository) {}
    
      async execute(params: IPageParameters): Promise<IPaginatedResponse<IStatuses>> {
        return this.repo.getStatuses(params);
      }
}