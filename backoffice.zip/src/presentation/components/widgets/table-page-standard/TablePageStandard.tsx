import React from 'react'
import type { CustomTableProps } from '../../ui/table/table.interface'
import CustomTable from '../../ui/table/table.component'
import { ContainerPageGrid } from '../../containers/container-page-grid/ContainerPageGrid';
import type {IContainerPageProp} from '../../containers/container-page-grid/ContainerPageGrid';

export interface ITablePageProps<T>

  extends Omit<IContainerPageProp, 'children'>,
    Pick<
      CustomTableProps,
      | 'columns'
      | 'data'
      | 'page'
      | 'pageSize'
      | 'totalCount'
      | 'handleChangePage'
      | 'handleChangeRowsPerPage'
      | 'sortBy'
      | 'sortDescending'
      | 'onRequestSort'
      | 'actions'
      | 'contextType'
    > {}

export function TablePageStandard<T>(props: ITablePageProps<T>) {
  const {
    // Props de ContainerPageGrid
    description,
    title,
    count,
    loading,
    filter,
    // Props de CustomTable
    columns,
    data,
    page,
    pageSize,
    totalCount,
    handleChangePage,
    handleChangeRowsPerPage,
    sortBy,
    sortDescending,
    onRequestSort,
    actions,
    contextType,
  } = props;

  return (
    <ContainerPageGrid
      description={description}
      title={title}
      count={count}
      loading={loading}
      filter={filter}
    >
      <CustomTable
        columns={columns}
        data={data}
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        handleChangePage={handleChangePage}
        handleChangeRowsPerPage={handleChangeRowsPerPage}
        sortBy={sortBy}
        sortDescending={sortDescending}
        onRequestSort={onRequestSort}
        actions={actions}
        contextType={contextType}
      />
    </ContainerPageGrid>
  )
}

export default TablePageStandard
