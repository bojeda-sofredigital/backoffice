import React, { useState, useEffect, type ChangeEvent } from 'react'
import { DualList, type ItemList } from '../../ui/dual-list/DualList'
import { CustomSearchInput } from '../../ui/inputs/search-inputs/search-input.component'
import { CustomStack } from '../../ui/stack/Stack'

export interface ICustomDualList {
  initLeft: ItemList[]
  initRight: ItemList[]
  titleLeft: string
  titleRight: string
  /** Recibe los valores (value: string[]) de los grupos asignados */
  handleChange: (assignedValues: string[]) => void
}

export const CustomDualList: React.FC<ICustomDualList> = ({
  initLeft,
  initRight,
  titleLeft,
  titleRight,
  handleChange
}) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [checked, setChecked] = useState<ItemList[]>([])
  const [left, setLeft] = useState<ItemList[]>(initLeft)
  const [right, setRight] = useState<ItemList[]>(initRight)

  // Sincroniza con props
  useEffect(() => {
    setLeft(initLeft)
  }, [initLeft])

  useEffect(() => {
    setRight(initRight)
  }, [initRight])

 
  const updateRight: React.Dispatch<React.SetStateAction<ItemList[]>> = (value) => {

    setRight(value)

    const newRight: ItemList[] =
      typeof value === 'function'
        ? (value as (prev: ItemList[]) => ItemList[])(right)
        : value

    const result: string[] = newRight.map((i) => i.value);

    handleChange(result);
  }

  const filteredLeft = left.filter((item) =>
    item.value.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const onSearchChange = (e: ChangeEvent<HTMLInputElement>) =>
    setSearchTerm(e.target.value)
  const onClearSearch = () => setSearchTerm('')

  return (
    <>
      <CustomStack direction="row" spacing={2} sx={{ mb: 2 }}>
        <CustomSearchInput
          value={searchTerm}
          onChange={onSearchChange}
          onClick={onClearSearch}
        />
      </CustomStack>

      <DualList
        checked={checked}
        setChecked={setChecked}
        left={filteredLeft}
        setLeft={setLeft}
        right={right}
        setRight={updateRight}
        titleLeft={titleLeft}
        titleRight={titleRight}
      />
    </>
  )
}

export default CustomDualList
