export interface IProfileFormValues {
  name: string;
  description: string;
  statusId: number;
  groups: string[];
}

