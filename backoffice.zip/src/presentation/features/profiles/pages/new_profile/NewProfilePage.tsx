import React, { useState } from 'react'
import { useForm, FormProvider } from 'react-hook-form'
import { ContainerPage } from '../../../../components/containers/container-page/ContainerPage'
import StepperWrapperBackOfficeDefault from '../../../../components/ui/step/stepper-wrapper-backoffice-default'
import StepNavigationBackOffice,{ type StepType } from '../../../../components/ui/step/step-navigation-backoffice'
import { CustomBox } from '../../../../components/ui/box/CustomBox'
import type { IProfileFormValues } from '../shared/components/profile-form-values/IProfileFormValues'
import { DEFAULT_PROFILE } from '../shared/constants/InitFormProfile'
import { StepOneProfile } from './components/step-one-profile/StepOneProfile'
import { StepTwoProfile } from './components/step-two-profile/StepTwoProfile'
import { ActionStep } from './components/action-step/ActionStep'
import  { CheckListIcon, UserIcon } from '../../../../components/ui/icons'
import { useCreateProfile } from '../../hooks/useCreateProfile'
import { useNavigate } from 'react-router-dom'
import { eToast, Toast } from '../../../../components/ui/toast/CustomToastService'
import Typography from '@mui/material/Typography'
import Button from '../../../../components/ui/button/button.component'
import { ResultSuccess } from './components/result-success/ResultSuccess'


const STEPS: StepType[] = [
  { show: true, active: false, icon: <UserIcon />, title: 'Nombre' },
  { show: true, active: false, icon: <CheckListIcon />, title: 'Asignación' }
]

export const NewProfilePage: React.FC = () => {

  const [activeStep, setActiveStep] = useState(0);
  const [isSuccess, setIsSuccess] = useState(false);
  const [created, setCreated] = useState<(IProfileFormValues & { id: string }) | null>(null);
  const form = useForm<IProfileFormValues>({
    defaultValues: DEFAULT_PROFILE,
    mode: 'onChange',          
    reValidateMode: 'onChange' 
  });
  const { create, loading: creating, error: createError } = useCreateProfile();
  const navigate = useNavigate()

  const navSteps = STEPS.map((st, i) => ({
    ...st,
   active: isSuccess ? isSuccess : i === activeStep
  }))

   const resetFlow = () => {
      form.reset(DEFAULT_PROFILE)
      setActiveStep(0)
      setIsSuccess(false)
  }

  const nextStep = async () => {

    const fields = activeStep === 0
      ? ['name', 'description', 'status']
      : ['groups']

  
    const ok = await form.trigger(fields as any)
    if (ok) setActiveStep((s) => s + 1)
  }

  const prevStep = () => setActiveStep((s) => s - 1)

  const onSubmit = async (data: IProfileFormValues) => {
    try {
      const newId = await create(data);
      setCreated({ ...data, id: newId });

      Toast({
        message: 'Perfil creado correctamente',
        type: eToast.Success
      });
      setIsSuccess(true);    
    } catch {
      Toast({
        message: 'Error al crear el perfil',
        type: eToast.Error
      });
    }
  }

  return (
    <ContainerPage description="NewProfilePage" title="Alta de Perfil">
      <FormProvider {...form}>
        <StepperWrapperBackOfficeDefault>
          <StepNavigationBackOffice steps={navSteps} />
        </StepperWrapperBackOfficeDefault>

       
        <CustomBox sx={{ p: '0 4rem', minHeight: 300 }}>
          {isSuccess ? (
            <CustomBox  py={6} sx={{justifyItems: 'center'}}  >
              <ResultSuccess perfil={created?.name??'EESS ABanderada'} />
            </CustomBox>
          ) : activeStep === 0 ? (
            <StepOneProfile />
          ) : (
            <StepTwoProfile />
          )}
        </CustomBox>

        {createError && !isSuccess && (
          <Typography color="error" align="center">
            {createError}
          </Typography>
        )}


        <CustomBox sx={{ mt: 4, display: 'flex', justifyContent: 'center' }}>
          {isSuccess ? (
            <Button variant="primary" onClick={resetFlow} title='Volver' />
          ) : (
            <ActionStep
                handleNext={activeStep === STEPS.length - 1 ? form.handleSubmit(onSubmit) : nextStep}
                handleBack={prevStep}
                isValid={form.formState.isValid}
                isLoading={creating} 
                steps={navSteps}/>
          )}
        </CustomBox>
      </FormProvider>
    </ContainerPage>
  )
}


