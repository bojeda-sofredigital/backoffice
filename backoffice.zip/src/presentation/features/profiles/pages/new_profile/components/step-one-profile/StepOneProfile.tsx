import React from 'react'
import { TitleStep } from '../title-step/TitleStep'
import { ProfileForm } from '../../../shared/components/profile-form-values/ProfileFormValues'

export const StepOneProfile: React.FC = () => (
  <>
    <TitleStep
      title="Nombre y descripción del perfil"
      subtitle="Escriba un nombre, descripción del grupo y el estado del perfil."
    />
    <ProfileForm />
  </>
)