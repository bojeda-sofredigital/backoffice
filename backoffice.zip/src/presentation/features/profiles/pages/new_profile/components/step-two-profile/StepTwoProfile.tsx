import React from 'react'
import { useFormContext, Controller } from 'react-hook-form'

import { TitleStep } from '../title-step/TitleStep'
import DualGroupAD from '../../../../../../components/widgets/dual-group-ad/DualGroupAD'
import Typography from '@mui/material/Typography'
import type { IProfileFormValues } from '../../../shared/components/profile-form-values/IProfileFormValues'

export const StepTwoProfile: React.FC = () => {
  const { control } = useFormContext<IProfileFormValues>()

  return (
    <>
      <TitleStep
        title="Asignación de Grupos"
        subtitle="Selecciona los grupos AD para este perfil."
      />

      <Controller
        name="groups"
        control={control}
        rules={{
          validate: (v) =>
            v.length > 0 || 'Debes asignar al menos un grupo'
        }}
        render={({ field, fieldState: { error } }) => (
          <>
            <DualGroupAD
              selectedGroups={field.value}
              onChange={field.onChange}
            />
            {error && (
              <Typography color="error" variant="caption">
                {error.message}
              </Typography>
            )}
          </>
        )}
      />
    </>
  )
}
