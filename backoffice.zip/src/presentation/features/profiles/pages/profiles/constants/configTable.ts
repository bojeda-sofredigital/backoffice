import type { IColumn } from "../../../../../components/ui/table/table.interface";

export const Headers: IColumn[] =[{
    align: 'left',
    id: 'name',
    label: 'Perfil'
},{
    align: 'left',
    id: 'creationDate',
    label: 'Fecha de creación'
},{
    align: 'left',
    id: 'lastChange',
    label: 'Ultima modificación'
},{
    align: 'left',
    id: 'groups',
    label: 'Grupos AD'
},{
    align: 'left',
    id: 'state',
    label: 'Estado'
},{
    align: 'left',
    id: 'actions',
    label: 'Acciones'
}];