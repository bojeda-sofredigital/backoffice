import React, { useContext, useState } from 'react'

import { Headers } from './constants/configTable';

import { EditProfile } from './components/edit-profile/EditProfile';

import TablePageStandard from '../../../../components/widgets/table-page-standard/TablePageStandard';
import { useProfilesPage } from '../../hooks/useProfilesPage';



export const ProfilesPage: React.FC = () => {
  const {
    rows,
    loading,
    count,
    params,
    openEdit,
    setOpenEdit,
    filterButtons,
    actions,
    handlers: {
      handlePageChange,
      handleRowsPerPage,
      handleSort,
    },
  } = useProfilesPage()

 return (
    <>
      <EditProfile openEdit={openEdit} setOpenEdit={setOpenEdit} />

      <TablePageStandard
        description="ProfilesPage"
        title="Gestión de perfiles"
        count={count}
        loading={loading}
        filter={filterButtons}
        columns={Headers}
        data={rows}
        page={params.page - 1}
        pageSize={params.pageSize}
        totalCount={count}
        handleChangePage={handlePageChange}
        handleChangeRowsPerPage={handleRowsPerPage}
        sortBy={params.sortBy ?? undefined}
        sortDescending={params.sortDescending}
        onRequestSort={handleSort}
        actions={actions}
        contextType="profiles"
      />
    </>
  )
}
