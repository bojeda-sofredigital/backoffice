import React, { useState } from 'react'
import CustomModal from '../../../../../../components/ui/modal/modal.component'
import { ProfileForm } from '../../../shared/components/profile-form-values/ProfileFormValues'
import type { ProfileFormValues } from '../../../new_profile/NewProfilePage'

interface IEditProfile{
    openEdit: any,
    setOpenEdit: any
}
export const EditProfile: React.FC<IEditProfile> = ({openEdit,setOpenEdit}) => {
 

  const onClose = ()=>{
    setOpenEdit(false);
  }
  return (
    <CustomModal open={openEdit} onClose={onClose} onOk={function (): void {
      throw new Error('Function not implemented.')
    } } onCancel={function (): void {
      throw new Error('Function not implemented.')
    } }>
        <ProfileForm onSubmit={function (v: ProfileFormValues): void {
        throw new Error('Function not implemented.')
      } } />
      
    </CustomModal>
  )
}
