// src/presentation/mappers/profileMapper.ts

import { styled } from "@mui/material/styles";
import type { IProfile } from "../../../../domain/entities/IProfile";
import { CustomStack } from "../../../components/ui/stack/Stack";
import { EditActionIcon } from "../../../components/ui/icons";
import type { IRow } from "../../../components/ui/table/table.interface";

export interface IProfileRow extends IRow {
  name: string; 
  state: any;
  creationDate: string;
  lastChange: string
  groups: any; 
  background?: string;
}

export function toProfileRow(p: IProfile,callbackEdit: any): IProfileRow {

  const styleContentElement= {
    justifyContent: "left",
    paddingLeft: "5%"
  };

  const WrapperContainerEdit = styled('div')(({ theme }) => ({
  cursor: 'pointer'
  }));

  const WrapperContainerStatus = styled('div')(({theme})=>({
    color: p.statusColor,
    paddingLeft: '1%'
  }));
  const buttonEdit = <>
                <CustomStack direction='row' spacing={2} sx={styleContentElement}>
                     <span>
                        {p.groups.length}
                     </span>
                     <WrapperContainerEdit>
                        <EditActionIcon handleClick={callbackEdit} parameterHandleClick={p} />
                      </WrapperContainerEdit>
                </CustomStack>
              </>;

  const stateComp = <>
    <WrapperContainerStatus>
      {p.statusDescription}
    </WrapperContainerStatus>
  </>
  return {
    id: p.id,
    name: p.name,
    creationDate: 'backendmock',
    lastChange:'backendmock',
    state: stateComp,
    groups: buttonEdit,
  };
}
