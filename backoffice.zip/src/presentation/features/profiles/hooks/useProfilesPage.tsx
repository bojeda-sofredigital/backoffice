import { useContext, useState, useCallback, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { DependencyContext } from '../../../contexts/DependencyContext'
import { INITIAL_PARAMS_TABLE } from '../../shared/constants/initialsParamTable'
import { useGetProfiles } from './useGetProfiles'
import { toProfileRow, type IProfileRow } from '../mappers/profileMapper'
import { CustomStack } from '../../../components/ui/stack/Stack'
import Button from '../../../components/ui/button/button.component'
import { NEW_PROFILE } from '../../../router/routes'
import type { IAction } from '../../../components/ui/table/table-actions/actions.interface'
import type { IRow } from '../../../components/ui/table/table.interface'

export function useProfilesPage() {
  const navigate = useNavigate()
  const [openEdit, setOpenEdit] = useState(false)
  const { getProfiles } = useContext(DependencyContext)
  const { result, loading, params, setParams } =  useGetProfiles(getProfiles, INITIAL_PARAMS_TABLE);


  const rows: IProfileRow[] = useMemo(
    () =>
      result?.data.map((p) =>
        toProfileRow(p, (row: any) => {         
          console.log('edit row', row)
        })
      ) ?? [],
    [result?.data]
  )

  const handlePageChange = useCallback(
    (_: any, newPage: number) =>
      setParams({ ...params, page: newPage + 1 }),
    [params, setParams]
  )
  const handleRowsPerPage = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setParams({
        ...params,
        pageSize: parseInt(e.target.value, 10),
        page: 1,
      }),
    [params, setParams]
  )
  const handleSort = useCallback(
    (columnId: string, desc: boolean) =>
      setParams({ ...params, sortBy: columnId, sortDescending: desc }),
    [params, setParams]
  )

  const filterButtons = useMemo(
    () => (
      <CustomStack direction="row" spacing={2}>
        <Button
          variant="primary"
          title="Crear nuevo perfil"
          onClick={() => navigate(NEW_PROFILE.name)}
        />
        <Button
          variant="secondary"
          title="Filtrar"
          onClick={() => setOpenEdit(true)}
        />
      </CustomStack>
    ),
    [navigate]
  )

  const actions: IAction[] = useMemo(
    () => [
      {
        icon: <Button variant="secondary" title="Editar" />,
        onClick: (row: IRow) => console.log('Editar fila', row),
      },
    ],
    []
  )

  return {
    rows,
    loading,
    count: result?.count ?? 0,
    params,
    openEdit,
    setOpenEdit,
    filterButtons,
    actions,
    handlers: {
      handlePageChange,
      handleRowsPerPage,
      handleSort,
    },
  }
}
