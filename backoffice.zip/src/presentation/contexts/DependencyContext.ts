import React from 'react';

import { GetProfilesUseCase } from '../../application/usecases/GetProfilesUseCase';
import { ProfileRepository } from '../../infrastructure/adapters/http/ProfileRepository';
import { UpdateProfileUseCase } from '../../application/usecases/UpdateProfileUseCase';
import { GetGroupsUseCase } from '../../application/usecases/GetGroupsUseCase';
import { GroupRepository } from '../../infrastructure/adapters/http/GroupRepository';
import { CreateProfileUseCase } from '../../application/usecases/CreateProfilesUseCase';
import { GetProfileStatusesUseCase } from '../../application/usecases/GetProfileStatusesUseCase';

const profileRepo = new ProfileRepository();
const groupRepo = new GroupRepository();

export interface IDependencies{
  getProfiles: GetProfilesUseCase,
  updateProfile: UpdateProfileUseCase,
  getGroups: GetGroupsUseCase,
  createProfile: CreateProfileUseCase,
  getProfileStatuses: GetProfileStatusesUseCase
}


export const defaultDependencies: IDependencies = {
  getProfiles: new GetProfilesUseCase(profileRepo),
  updateProfile: new UpdateProfileUseCase(profileRepo),
  getGroups: new GetGroupsUseCase(groupRepo),
  createProfile: new CreateProfileUseCase(profileRepo),
  getProfileStatuses: new GetProfileStatusesUseCase(profileRepo)
};

export const DependencyContext = React.createContext<IDependencies>(defaultDependencies);
