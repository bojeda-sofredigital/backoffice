export const env = {
  baseURL: import.meta.env.VITE_BASE_URL + "v1/api/" || "http://localhost:3000",
  pageSize: import.meta.env.VITE_PAGE_SIZE_DEFAULT || 10
};