import type { IPageParameters, IPaginatedResponse } from "../../../application/common/IPaginatedResponse";
import type { IGroupRepository } from "../../../application/interfaces/IGroupRepository";
import type { IGroup } from "../../../domain/entities/IGroup";
import { apiHandler } from "./apiHandler";

export class GroupRepository implements IGroupRepository{


    async getGroups(params: IPageParameters): Promise<IPaginatedResponse<IGroup>> {
       const response = await apiHandler.get<IPaginatedResponse<IGroup>>(
             "/AD/groups",
             { queryParams: params }
           );
        return response.data;
    }


}