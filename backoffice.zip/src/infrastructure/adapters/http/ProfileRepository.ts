import type { IProfileRepository } from "../../../application/interfaces/IProfileRepository";
import type { IPageParameters, IPaginatedResponse } from "../../../application/common/IPaginatedResponse";
import type { IProfile } from "../../../domain/entities/IProfile";
import { apiHandler } from "./apiHandler";
import type { IProfileUpdateDto } from "../../../application/dtos/IProfileUpdateDto";
import type { IProfileCreateDto } from "../../../application/dtos/IProfileCreateDto";
import type { IStatuses } from "../../../domain/entities/IStatuses";
import { Mock } from "./mock/getProfilesmock";
export class ProfileRepository implements IProfileRepository {
 

  async updateProfile(id: string, payload: IProfileUpdateDto){
    const res = await apiHandler.put<IProfile>(`/profiles/${id}`,{},payload);

    return res.data;
  }
  async getProfiles(params: IPageParameters): Promise<IPaginatedResponse<IProfile>> {
    
    //return Mock;
    const response = await apiHandler.get<IPaginatedResponse<IProfile>>(
      "/profiles",
      { queryParams: params }
    );
    return response.data;
    
  }

   async createProfile(dto: IProfileCreateDto): Promise<string> {

      const res = await apiHandler.post<{ id: string }, IProfileCreateDto>(
        '/profiles',
        {},
        dto
      )
      return res.data.id;
   }

  

    async getStatuses(params: IPageParameters): Promise<IPaginatedResponse<IStatuses>> {
          const response = await apiHandler.get<IPaginatedResponse<IStatuses>>(
                "/profiles/statuses",
                { queryParams: params }
              );
          return response.data;
    }

}

